Najeon Workshop / Lacquer & Pearl — corrected Joseon-style NPC portraits

40 individual PNG portraits, 5 rows × 8 columns.
Each portrait: 188 × approx. 201–202 px, including its beige card background (NOT transparent).
Rows/cols are indexed from TOP-LEFT. npc_r01c01.png = first row first column.

Files:
- portraits/: 40 individually cropped PNGs
- npc_sheet.png: full unnumbered sheet
- npc_sheet_numbered.png: numbered lookup sheet
- npc_manifest.json / csv: proposed NPC roles, gender presentation labels, and names

The names/roles are creative assignments and not historically verified biographies.
Do not randomly assign a portrait to a role that contradicts its appearance.
Keep major master/story characters fixed. For generic commission NPCs, select role-compatible portraits and choose a non-duplicate name per active commission batch. Persist generated name and portrait ID along with commission ID so revisiting the commission does not change them.

The modified artwork improves period plausibility but is not a museum-level historically certified reproduction.
